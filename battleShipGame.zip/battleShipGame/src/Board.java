import java.util.Objects;

public class Board  {

   private int verse;
   private int column;
   private boolean empty;

    public Board(int verse, int column, boolean empty) {
        this.verse = verse;
        this.column = column;
        this.empty = empty;
    }

    protected int getVerse() { return verse; }

    protected int getColumn() { return column; }

    protected boolean isEmpty() {
        return empty;
    }

    protected void isNotEmpty(){
        this.empty=false;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Board board = (Board) o;
        return verse == board.verse &&
                column == board.column;
    }

    @Override
    public int hashCode() {
        return Objects.hash(verse, column);
    }


}
