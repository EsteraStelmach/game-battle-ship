import java.util.ArrayList;
import java.util.List;

public class Ship {


  final int shipLength;
  private int shipLengthForChange;
  private List<Board> shipPlace=new ArrayList<Board>();
  private int sunk=0;

  public Ship(int shipLength) {
        this.shipLength = shipLength;
        this.shipLengthForChange=shipLength;
  }

    protected int getShipLength() {
        return shipLength;
    }

    public void addSunk() {
        sunk++;
    }

    protected List<Board> shipPlace() {
        return shipPlace;
    }

    protected int getShipLengthForChange() {
        return shipLengthForChange;
    }

    protected void setShipLengthForChange(int shipLengthForChange) {
        this.shipLengthForChange = shipLengthForChange;
    }

    protected boolean isShipSunk(){
        if(sunk==getShipLength()){return true;}
        else {return false;}
    }









































}




